import React from "react";
import SearchBar from "./SearchBar";
import RenderList from "./RenderList";
import { Container } from "@material-ui/core";
import "./main.css";
import { v4 as uuidv4 } from "uuid";
class App extends React.Component {
  state = {
    todoText: "",
    todoTextDetail: [],
    id: uuidv4(),
  };
  handleSubmit = (e) => {
    if (this.state.todoText.length > 0) {
      e.preventDefault();
      const todoText = {
        id: uuidv4(),
        inputValue: this.state.todoText,
      };
      const todoTextDetail = [...this.state.todoTextDetail];
      todoTextDetail.push(todoText);
      this.setState({
        todoTextDetail,
        todoText: "",
      });
    }
  };
  handleChangeInput = (e) => {
    this.setState({
      todoText: e.target.value,
    });
  };
  handleDelete = (id) => {
    const filteredItems = this.state.todoTextDetail.filter(
      (item) => item.id !== id
    );
    this.setState({
      todoTextDetail: filteredItems,
    });
  };

  clearList = (e) => {
    this.setState({
      todoTextDetail: "",
    });
  };
  render() {
    return (
      <>
        <Container>
          {/* <SearchBar
            todoText={this.state.todoText}
            todoTextDetail={this.state.todoTextDetail}
            handleSubmit={this.handleSubmit}
            handleChangeInput={this.handleChangeInput}
          /> */}
          <SearchBar
            todoText={this.state.todoText}
            handleSubmit={this.handleSubmit}
            handleChangeInput={this.handleChangeInput}
            defaultBtn={this.state.defaultBtn}
          />
          <RenderList
            todoTextDetail={this.state.todoTextDetail}
            clearList={this.clearList}
            handleDelete={this.handleDelete}
          />
        </Container>
      </>
    );
  }
}
export default App;
