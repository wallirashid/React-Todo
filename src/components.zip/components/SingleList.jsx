import React from "react";

class SingleList extends React.Component {
  state = {
    status: false,
  };

  handleCheck = (currentId) => {
    if (currentId) {
      this.setState({
        status: true,
      });
    }
  };

  render() {
    console.log("Single list props-------", this.props);
    return (
      <>
        <li>
          <span
            className={
              this.state.status === true ? "success-line" : "without-line"
            }
          >
            {this.props.todoTextData.inputValue}
          </span>
          <span>
            <i
              onClick={() => this.handleCheck(this.props.todoTextData.id)}
              className={`fa fa-check success-style`}
            ></i>
            <i
              className="fa fa-times danger-style"
              onClick={() => {
                this.props.handleDelete(this.props.todoTextData.id);
              }}
            ></i>
          </span>
        </li>
      </>
    );
  }
}
export default SingleList;
