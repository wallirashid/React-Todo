import React from "react";
import { TextField, Button } from "@material-ui/core";
import "./main.css";
class SearchBar extends React.Component {
  render() {
    const {
      //props
      todoText,
      defaultBtn,
      //functions
      handleSubmit,
      handleChangeInput,
    } = this.props;
    return (
      <>
        <div className="form-search">
          <form noValidate autoComplete="off" onSubmit={handleSubmit}>
            <TextField
              id="standard-basic"
              placeholder="Task"
              onChange={handleChangeInput}
              value={todoText}
            />

            <Button
              variant="contained"
              color="primary"
              onClick={handleSubmit}
              // disabled={todoText.length == 0 ? true : ""}
            >
              Add Task
            </Button>
          </form>
        </div>
      </>
    );
  }
}
export default SearchBar;
